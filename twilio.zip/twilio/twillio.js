// npm install twilio 
// https://www.twilio.com/blog/make-phone-call-using-node-js-twilio-programmable-voice
// https://www.youtube.com/watch?v=CgNd6VgNzDk

require('dotenv').config();
const number = null
const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;
const client = require('twilio')(accountSid, authToken);

client.calls
  .create({
    from:'+15555552341',
    to: number,     
    url: 'https://demo.twilio.com/docs/voice.xml'
  })
  .then(call => console.log(call.sid));